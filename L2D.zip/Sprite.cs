using System;
using System.Drawing;

public class Sprite
{
    private string path;
    private Bitmap bitmap;
    private int width;
    private int height;
    private int subWidth;
    private int subHeight;

    public Sprite(string path,int subWidth, int subHeight)
    {
        this.path = path;
        this.subWidth = subWidth;
        this.subHeight = subHeight;
        LoadBitmap();
    }

    private void LoadBitmap()
    {
        try
        {
            bitmap = new Bitmap(path);
            width = bitmap.Width;
            height = bitmap.Height;
        }
        catch (Exception ex)
        {
            System.Windows.Forms.MessageBox.Show($"Error loading sprite: {ex.Message}");
        }
    }

    public string Path { get => path; set { path = value; LoadBitmap(); } }
    public Bitmap Bitmap { get => bitmap; }
    public int Width { get => width; set => width = value; }
    public int Height { get => height; set => height = value; }
    public int SubWidth { get => subWidth; set => subWidth = value; }
    public int SubHeight { get => subHeight; set => subHeight = value; }
}