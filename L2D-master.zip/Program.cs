namespace L2D;

using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

static class Program
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new SpriteWindow());
    }
}

public class SpriteWindow : Form
{
    private Timer timer;
    private Bitmap sheet;
    private int frameWidth = 140;
    private int frameHeight = 140;
    private int currentFrame = 0;
    private int totalFrames;
    private Character character;
    private bool flipHorizontal = true;
    private float scale = 1f;

    // movement / behavior states
    private enum MoveState { WaitingToMove, Moving, Idling, Interact, Static, Sleep, PostInteractHold }
    private MoveState moveState = MoveState.WaitingToMove;
    private MoveState prevState = MoveState.WaitingToMove;

    private Random rnd = new Random();

    // common timers (ms)
    private int waitDurationMs;    // chosen T (10-20s) used for waiting / idling
    private int stateElapsedMs;
    private int moveDurationMs = 800; // set dynamically to keep constant speed
    private int moveElapsedMs;
    private Point startPos;
    private Point targetPos;
    private float moveSpeed = 300f; // pixels per second (consistent speed)

    // frame timing
    private int frameElapsedMs = 0;
    private int frameIntervalMs = 1000 / 12;

    // dragging/interact
    private bool dragging = false;
    private Point dragOffset;
    private bool sittingDueToTaskbarArea = false;
    private bool interactHoldUntilRelease = false;

    // sleep logic
    private int timeAwakeMs = 0;
    private int sleepThresholdMs; // random between 5-10min
    private int sleepDurationMs;  // computed when entering sleep

    // store previous state meta for restoring after interact
    private MoveState savedPrevState;
    private int savedPrevWaitDurationMs;
    private int savedPrevStateElapsedMs;

    public SpriteWindow()
    {
        TopMost = true;
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.CenterScreen;
        Width = (int)(frameWidth * scale);
        Height = (int)(frameHeight * scale);
        BackColor = Color.Magenta;
        TransparencyKey = Color.Magenta;
        DoubleBuffered = true;

        string folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets");
        if (!Directory.Exists(folder))
        {
            MessageBox.Show("Missing /assets folder");
            Close(); return;
        }

        // initialize character and attempt to load known animation sheets if present
        character = new Character(0, 0, frameWidth, frameHeight);
        Action<string> tryAdd = (name) =>
        {
            var files = Directory.GetFiles(folder, name + "*.png");
            if (files.Length > 0)
                character.AddSprite(name.ToLower(), new Sprite(files[0], frameWidth, frameHeight));
        };

        tryAdd("idle");
        tryAdd("dance");
        tryAdd("walk");
        tryAdd("touch");
        tryAdd("moutou");
        tryAdd("moutou2");
        tryAdd("touzhuai");
        tryAdd("sit");
        tryAdd("sleep");

        if (character.CurrentSprite == null)
        {
            MessageBox.Show("No sprite loaded for character. Put at least an 'idle.png' in /assets");
            Close(); return;
        }

        LoadCurrentSpriteSheet();

        // initial placement: center of primary screen
        var screen = Screen.PrimaryScreen.Bounds;
        int initX = (screen.Width - character.getWidth()) / 2;
        int initY = (screen.Height - character.getHeight()) / 2;
        character.SetX(initX);
        character.SetY(initY);
        Location = new Point(character.GetX(), character.GetY());

        // init timings
        waitDurationMs = rnd.Next(10, 21) * 1000;
        stateElapsedMs = 0;
        // sleep thresholds
        sleepThresholdMs = rnd.Next(5, 11) * 60 * 1000; // 5..10 min
        timeAwakeMs = 0;

        // timer
        timer = new Timer();
        timer.Interval = 16;
        timer.Tick += Timer_Tick;
        timer.Start();

        // mouse events
        this.MouseClick += SpriteWindow_MouseClick;
        this.MouseDown += SpriteWindow_MouseDown;
        this.MouseMove += SpriteWindow_MouseMove;
        this.MouseUp += SpriteWindow_MouseUp;
    }

    private void LoadCurrentSpriteSheet()
    {
        try
        {
            var sp = character.CurrentSprite;
            if (sp != null)
            {
                sheet?.Dispose();
                sheet = new Bitmap(sp.Path);
                totalFrames = Math.Max(1, sheet.Width / frameWidth);
                currentFrame = 0;
            }
        }
        catch { /* ignore load errors at runtime */ }
    }

    private void Timer_Tick(object sender, EventArgs e)
    {
        int delta = timer.Interval;
        timeAwakeMs += delta;

        // frame timing at ~12 FPS
        frameElapsedMs += delta;
        if (frameElapsedMs >= frameIntervalMs)
        {
            currentFrame = (currentFrame + 1) % Math.Max(1, totalFrames);
            frameElapsedMs -= frameIntervalMs;
            Invalidate();
        }

        // If sleeping condition reached and not already sleeping => enter Sleep
        if (moveState != MoveState.Sleep && timeAwakeMs >= sleepThresholdMs)
        {
            EnterSleep();
        }

        switch (moveState)
        {
            case MoveState.WaitingToMove:
                stateElapsedMs += delta;
                if (stateElapsedMs >= waitDurationMs)
                {
                    StartMoveToRandomTarget();
                }
                break;

            case MoveState.Moving:
                moveElapsedMs += delta;
                float t = Math.Min(1f, (float)moveElapsedMs / Math.Max(1, moveDurationMs));
                int nx = (int)(startPos.X + (targetPos.X - startPos.X) * t);
                int ny = (int)(startPos.Y + (targetPos.Y - startPos.Y) * t);
                character.SetX(nx);
                character.SetY(ny);
                Location = new Point(nx, ny);

                if (t >= 1f)
                {
                    // arrived, go to Idling using same T as previous wait
                    stateElapsedMs = 0;
                    moveState = MoveState.Idling;
                    // Idling animation selection handled on enter
                    EnterIdling();
                }
                break;

            case MoveState.Idling:
                stateElapsedMs += delta;
                // maybe change dance/idle mid-way if scheduled
                if (idlingSwitchAtMs > 0 && stateElapsedMs >= idlingSwitchAtMs && !idlingSwitched)
                {
                    idlingSwitched = true;
                    ToggleIdlingAnimation();
                }
                if (stateElapsedMs >= waitDurationMs)
                {
                    waitDurationMs = rnd.Next(10, 21) * 1000;
                    stateElapsedMs = 0;
                    moveState = MoveState.WaitingToMove;
                    // when leaving idling reset any idling meta
                    idlingSwitchAtMs = 0;
                    idlingSwitched = false;
                }
                break;

            case MoveState.Interact:
                // if the interact is held (drag), don't auto-transition until release
                if (!interactHoldUntilRelease)
                {
                    stateElapsedMs += delta;
                    if (stateElapsedMs >= waitDurationMs)
                    {
                        // after interact we do PostInteractHold for 3-5s (idle or walk)
                        EnterPostInteractHold();
                    }
                }
                break;

            case MoveState.PostInteractHold:
                stateElapsedMs += delta;
                if (stateElapsedMs >= waitDurationMs)
                {
                    // restore previous state and give extra time equal to this hold
                    RestorePreviousStateWithExtra(waitDurationMs);
                }
                break;

            case MoveState.Static:
                // remain static until user drags away (handled in MouseUp/Move)
                break;

            case MoveState.Sleep:
                stateElapsedMs += delta;
                if (stateElapsedMs >= sleepDurationMs)
                {
                    // wake up: reset awake counters and return to waiting
                    timeAwakeMs = 0;
                    sleepThresholdMs = rnd.Next(5, 11) * 60 * 1000;
                    stateElapsedMs = 0;
                    waitDurationMs = rnd.Next(10, 21) * 1000;
                    moveState = MoveState.WaitingToMove;
                    SetAnimationIfExists("idle");
                }
                break;
        }
    }

    // Idling change scheduling
    private int idlingSwitchAtMs = 0;
    private bool idlingSwitched = false;

    private void EnterIdling()
    {
        // pick idle or dance initially (50/50)
        bool startDance = rnd.NextDouble() < 0.5;
        SetAnimationIfExists(startDance ? "dance" : "idle");

        // schedule possible mid-stage switch (50% chance)
        if (rnd.NextDouble() < 0.5)
        {
            // schedule switch time between 30%..60% of waitDuration.. up to full waitDuration
            double min = 0.3 * waitDurationMs;
            double max = 0.6 * waitDurationMs;
            idlingSwitchAtMs = (int)(min + rnd.NextDouble() * (Math.Max(0, max - min)));
            idlingSwitched = false;
        }
        else
        {
            idlingSwitchAtMs = 0;
            idlingSwitched = false;
        }
    }

    private void ToggleIdlingAnimation()
    {
        // switch between idle and dance if both exist
        if (character.CurrentAnimation == "idle" && character.CurrentSprite != null && TrySetAnimation("dance")) return;
        if (character.CurrentAnimation == "dance" && character.CurrentSprite != null && TrySetAnimation("idle")) return;
    }

    private void StartMoveToRandomTarget()
    {
        var screen = Screen.PrimaryScreen.Bounds;
        int maxX = Math.Max(0, screen.Width - character.getWidth());
        int maxY = Math.Max(0, screen.Height - character.getHeight());
        int tx = rnd.Next(0, maxX + 1);
        int ty = rnd.Next(0, maxY + 1);

        startPos = new Point(character.GetX(), character.GetY());
        targetPos = new Point(tx, ty);

        double dx = targetPos.X - startPos.X;
        double dy = targetPos.Y - startPos.Y;
        double dist = Math.Sqrt(dx * dx + dy * dy);
        moveDurationMs = Math.Max(150, (int)(dist / moveSpeed * 1000.0));

        moveElapsedMs = 0;
        moveState = MoveState.Moving;
        SetAnimationIfExists("walk");
        flipHorizontal = targetPos.X < startPos.X;
    }

    private void EnterSleep()
    {
        savedPrevState = moveState;
        moveState = MoveState.Sleep;
        stateElapsedMs = 0;
        // sleep duration scales with time awake (0.4..0.6) * timeAwake
        double factor = 0.4 + rnd.NextDouble() * 0.2;
        sleepDurationMs = Math.Max(2000, (int)(factor * timeAwakeMs));
        SetAnimationIfExists("sleep");
    }

    private void EnterPostInteractHold()
    {
        // choose idle or walk for 3..5s
        bool chooseWalk = rnd.NextDouble() < 0.5;
        savedPrevState = prevState;
        SetAnimationIfExists(chooseWalk ? "walk" : "idle");
        waitDurationMs = rnd.Next(3000, 5001);
        stateElapsedMs = 0;
        moveState = MoveState.PostInteractHold;
        // if walk chosen and we are stationary, we won't actually move; animation just shows walk.
    }

    private void RestorePreviousStateWithExtra(int extraMs)
    {
        // restore previous state (prevState stored before Interact)
        moveState = savedPrevState;
        // if previous state used waitDuration, extend it by extra
        if (moveState == MoveState.Idling || moveState == MoveState.WaitingToMove)
        {
            waitDurationMs += extraMs;
            // keep stateElapsedMs as before (we saved when entering Interact)
            stateElapsedMs = savedPrevStateElapsedMs;
        }
        // set animation to what prev state expects
        if (moveState == MoveState.Moving) SetAnimationIfExists("walk");
        if (moveState == MoveState.Idling) EnterIdling();
        if (moveState == MoveState.WaitingToMove) SetAnimationIfExists("idle");
    }

    private bool TrySetAnimation(string name)
    {
        if (character == null) return false;
        if (character.CurrentAnimation == name) return true;
        var sprites = new List<string>(); // nothing else needed here, just try set
        if (character != null)
        {
            // use existing Character.SetAnimation which checks ContainsKey
            character.SetAnimation(name);
            if (character.CurrentAnimation == name)
            {
                LoadCurrentSpriteSheet();
                return true;
            }
        }
        return false;
    }

    private void SetAnimationIfExists(string name)
    {
        if (TrySetAnimation(name))
        {
            // reset frame animation
            currentFrame = 0;
            frameElapsedMs = 0;
        }
    }

    private void SpriteWindow_MouseDown(object sender, MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left)
        {
            dragging = true;
            dragOffset = e.Location;

            // when starting drag, if player is near bottom area then sit and become Static
            var screen = Screen.PrimaryScreen.Bounds;
            int bottomAreaY = screen.Height - 50;
            if (Location.Y >= bottomAreaY - 10) // close to taskbar area
            {
                // sit and go into Static state until dragged out
                sittingDueToTaskbarArea = true;
                savedPrevState = moveState;
                savedPrevWaitDurationMs = waitDurationMs;
                savedPrevStateElapsedMs = stateElapsedMs;
                moveState = MoveState.Static;
                SetAnimationIfExists("sit");
            }
            else
            {
                // for normal drag, start 'touzhuai' interact animation
                savedPrevState = moveState;
                savedPrevWaitDurationMs = waitDurationMs;
                savedPrevStateElapsedMs = stateElapsedMs;
                moveState = MoveState.Interact;
                SetAnimationIfExists("touzhuai");
                // Interact duration won't be long — end on mouse up; use a fallback small duration
                waitDurationMs = 500;
                stateElapsedMs = 0;
            }
        }
    }

    private void SpriteWindow_MouseMove(object sender, MouseEventArgs e)
    {
        if (dragging)
        {
            Location = new Point(Location.X + e.X - dragOffset.X, Location.Y + e.Y - dragOffset.Y);
            character.SetX(Location.X);
            character.SetY(Location.Y);
            // if previously static due to bottom area and now moved away: exit Static and restore
            var screen = Screen.PrimaryScreen.Bounds;
            int bottomAreaY = screen.Height - 50;
            if (sittingDueToTaskbarArea && Location.Y < bottomAreaY - 60)
            {
                sittingDueToTaskbarArea = false;
                // restore previous state + small extra penalty so it doesn't immediately sleep/move
                moveState = savedPrevState;
                waitDurationMs = Math.Max(0, savedPrevWaitDurationMs) + rnd.Next(3000, 5001);
                stateElapsedMs = savedPrevStateElapsedMs;
                SetAnimationIfExists("idle");
            }
        }
    }

    private void SpriteWindow_MouseUp(object sender, MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left)
        {
            dragging = false;
            // if we were in an interact due to drag, after mouse up we go to PostInteractHold
            if (moveState == MoveState.Interact)
            {
                // set interact duration small then PostInteractHold will run
                stateElapsedMs = waitDurationMs; // force immediate transition
            }
            // if we were static and released, remain static until moved away (handled in MouseMove)
        }
    }

    private void SpriteWindow_MouseClick(object sender, MouseEventArgs e)
    {
        // click triggers Interact (touch/moutou)
        // save previous state to restore later
        savedPrevState = moveState;
        savedPrevWaitDurationMs = waitDurationMs;
        savedPrevStateElapsedMs = stateElapsedMs;

        moveState = MoveState.Interact;
        stateElapsedMs = 0;

        // choose animation based on click Y relative to character
        int playerY = Location.Y;
        if (e.Y + Location.Y > playerY + 40)
        {
            SetAnimationIfExists("touch");
        }
        else
        {
            // 50% moutou or moutou2
            SetAnimationIfExists(rnd.NextDouble() < 0.5 ? "moutou" : "moutou2");
        }

        // set duration for the interact animation (short)
        waitDurationMs = rnd.Next(800, 1201); // ~0.8..1.2s interact anim
        stateElapsedMs = 0;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        int x = (currentFrame % Math.Max(1, totalFrames)) * frameWidth;
        Rectangle src = new Rectangle(x, 0, frameWidth, frameHeight);

        Rectangle dest;
        if (flipHorizontal)
        {
            dest = new Rectangle((int)(frameWidth * scale), 0, -(int)(frameWidth * scale), (int)(frameHeight * scale));
        }
        else
        {
            dest = new Rectangle(0, 0, (int)(frameWidth * scale), (int)(frameHeight * scale));
        }

        // if (sheet != null)
        // {
        //     e.Graphics.DrawImage(sheet, dest, src, GraphicsUnit.Pixel);
        // }

        // draw debug rect
        using (Pen pen = new Pen(Color.Red, 1))
        {
            Rectangle rect = new Rectangle(0, 0, character.getWidth() - 1, character.getHeight() - 1);
            e.Graphics.DrawRectangle(pen, rect);

            // compute time-left for current animation/state
            int remainingMs = 0;
            string animName = character.CurrentAnimation ?? "(none)";
            switch (moveState)
            {
                case MoveState.Moving:
                    remainingMs = Math.Max(0, moveDurationMs - moveElapsedMs);
                    break;
                case MoveState.Idling:
                case MoveState.WaitingToMove:
                case MoveState.Interact:
                case MoveState.PostInteractHold:
                    remainingMs = Math.Max(0, waitDurationMs - stateElapsedMs);
                    break;
                case MoveState.Sleep:
                    remainingMs = Math.Max(0, sleepDurationMs - stateElapsedMs);
                    break;
                case MoveState.Static:
                default:
                    remainingMs = 0;
                    break;
            }

            // format as seconds.milliseconds (e.g. 1.234s)
            double secs = remainingMs / 1000.0;
            string label = $"{animName} {secs:0.000}s";

            // draw small semi-opaque background and text at top-left inside rect
            int pad = 4;
            using (Font f = new Font("Segoe UI", 8f, FontStyle.Regular, GraphicsUnit.Point))
            using (SolidBrush back = new SolidBrush(Color.FromArgb(180, 0, 0, 0)))
            using (SolidBrush fore = new SolidBrush(Color.White))
            {
                SizeF textSize = e.Graphics.MeasureString(label, f);
                RectangleF bg = new RectangleF(pad, pad, textSize.Width + pad * 2, textSize.Height + pad * 2);
                e.Graphics.FillRectangle(back, bg);
                e.Graphics.DrawString(label, f, fore, pad * 2, pad * 1.5f);
            }
        }
    }

    protected override bool ShowWithoutActivation => true;

    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams cp = base.CreateParams;
            cp.ExStyle |= 0x02000000; // WS_EX_COMPOSITED
            return cp;
        }
    }
}