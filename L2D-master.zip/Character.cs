using System;
using System.Collections.Generic;

public class Character
{
    private int x, y, width, height;
    private Dictionary<string, Sprite> sprites;
    private string currentAnimation;

    public Character(int x, int y, int width, int height)
    {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        sprites = new Dictionary<string, Sprite>();
        currentAnimation = null;
    }
    public int GetX()
    {
        return x;
    }
    public int GetY()
    {
        return y;
    }
    public void SetX(int x)
    {
        this.x = x;
    }
    public void SetY(int y)
    {
        this.y = y;
    }
    public int getWidth()
    {
        return width;
    }
    public int getHeight()
    {
        return height;
    }   

    public string CurrentAnimation { get => currentAnimation; set => currentAnimation = value; }
    public Sprite CurrentSprite
    {
        get => currentAnimation != null && sprites.ContainsKey(currentAnimation) ? sprites[currentAnimation] : null;
    }
    
    public void AddSprite(string name, Sprite sprite)
    {
        sprites[name] = sprite;
        if (currentAnimation == null)
            currentAnimation = name;
    }

    public void SetAnimation(string name)
    {
        if (sprites.ContainsKey(name))
            currentAnimation = name;
    }

    public bool CheckCollision(int px, int py)
    {
        return px >= x && px < x + width && py >= y && py < y + height;
    }
}